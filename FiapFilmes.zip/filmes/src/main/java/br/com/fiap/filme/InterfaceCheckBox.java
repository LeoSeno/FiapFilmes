package br.com.fiap.filme;

import javax.swing.JCheckBox;

public class InterfaceCheckBox extends JCheckBox {
	
	private static final long serialVersionUID = 1L;

	public InterfaceCheckBox(String texto) {
		super(texto);
	}
	
}
